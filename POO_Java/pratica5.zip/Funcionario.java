package pratica5;

public class Funcionario {
	private	String	nome;
	private String	rg;
	private	float	salarioBase;
	private	String	cpf;
	private	String	telefone;
	private float	salarioFinal;
	
								/*Construtor*/
	public Funcionario(String n, String RG, float salario, String CPF, String tel) {
		setNome(n);
		setRg(RG);
		setSalarioBase(salario);
		setCpf(CPF);
		setTelefone(tel);
	}
	public String getNome() {
		return nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}
	public String getRg() {
		return rg;
	}
	public void setRg(String rg) {
		this.rg = rg;
	}
	public Float getSalarioBase() {
		return salarioBase;
	}
	public void setSalarioBase(Float salarioBase) {
		if(salarioBase <= 0) {
			this.salarioBase = 0;
		}else {
			this.salarioBase = salarioBase;	
		}
	}
	public String getCpf() {
		return cpf;
	}
	public void setCpf(String cpf) {
		this.cpf = cpf;
	}
	public String getTelefone() {
		return telefone;
	}
	public void setTelefone(String telefone) {
		this.telefone = telefone;
	}
	public float getSalarioFinal() {
		return salarioFinal;
	}
	public void setSalarioFinal(float salarioFinal) {
		if(salarioFinal <= 0) {
			this.salarioFinal = salarioFinal;
		}else {
			this.salarioFinal = salarioFinal;
		}
	}
	void calcSalarioFinal(float salarioB, float mont) {
		float sFinal = 0;
		sFinal = salarioB + mont;
		setSalarioFinal(sFinal);
	}
	void zeraSalarioFinal() {
		setSalarioFinal(0);
	}
	
}
