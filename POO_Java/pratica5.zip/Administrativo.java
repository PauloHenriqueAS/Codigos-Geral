package pratica5;

public class Administrativo extends Funcionario{
	private	int nroHrsExtra;
	private float salarioExtra;
	
	public Administrativo(int hrs, String n, String RG, float salario, String CPF, String tel) {
		super(n, RG, salario, CPF, tel);
		setNroHrsExtra(hrs);
	}
	public int getNroHrsExtra() {
		return nroHrsExtra;
	}
	public void setNroHrsExtra(int nroHrsExtra) {
		if(nroHrsExtra <= 0 && this.nroHrsExtra == 0) {
			this.nroHrsExtra = 0;
		}else {
			this.nroHrsExtra += nroHrsExtra;	
		}
	}
	public float getSalarioExtra() {
		return salarioExtra;
	}
	public void setSalarioExtra(float salarioExtra) {
		if(salarioExtra <= 0) {
			this.salarioExtra = 0;
		}else {
			this.salarioExtra += salarioExtra;
		}
	}
	public void registrarHrsExtra(int hrs) {
		setNroHrsExtra(hrs);
	}
	public void calcSalarioF() {
		float aux, auxCal, salBase;
		salBase = getSalarioBase();
		auxCal = salBase * (1/100);
		aux = auxCal * this.nroHrsExtra;
		setSalarioExtra(aux);
	}
}
