package pratica5;
import java.util.Scanner;

public class Testa {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Vendedor listaVendedores[] = new Vendedor[5];
		Administrativo listaAdministrativo[] = new Administrativo[5];
		Scanner sc = new Scanner(System.in);
		
		//Vendedor v1 = new Vendedor(0,0, "paulo", "5522", 50000, "52335", "20004");
		//System.out.println("SalarioBase de paulo e: " + v1.getSalarioBase());
		for(int i=0; i<5; i++) {
			System.out.print("Digite o nome do vendedor " + i + ": ");
			String nomeV = sc.next();
			System.out.print("Digite o RG do vendedor: ");
			String rgV = sc.next();
			System.out.print("Digite o salario base do vendedor: ");
			Float salarioV = sc.nextFloat();
			System.out.print("Digite o CPF do vendedor: ");
			String cpfV = sc.next();
			System.out.print("Digite o telefone do vendedor: ");
			String telV = sc.next();
			//constroi o arrary e dps constroi cada posicao com os valores dos objetos
			
			listaVendedores[i] = new Vendedor(0, 0, nomeV, rgV, salarioV, cpfV, telV);
		}
		
		for(int i=0; i<5; i++) {
			System.out.print("Digite o nome do administrativo: ");
			String nomeA = sc.next();
			System.out.print("Digite o RG do administrativo: ");
			String rgA = sc.next();
			System.out.print("Digite o salario base do administrativo: ");
			Float salarioA = sc.nextFloat();
			System.out.print("Digite o CPF do administrativo: ");
			String cpfA = sc.next();
			System.out.print("Digite o telefone do administrativo: ");
			String telA = sc.next();
			
			listaAdministrativo[i] = new Administrativo(0, nomeA, rgA, salarioA, cpfA, telA);
		}
		sc.close();
	}

}
