package pratica5;

public class Vendedor extends Funcionario{
	private	final float comissao = 5;
	private	int nroVendas;
	private float montante;
	
	public Vendedor(float mont, int nro, String n, String RG, float salario, String CPF, String tel) {
		super(n, RG, salario, CPF, tel);
		setNroVendas(nro);
		setMontante(mont);
	}
	public float getMontante() {
		return montante;
	}
	public void setMontante(float montante) {
		if(montante <=0 && this.montante == 0) {
			this.montante = 0;
		}else {
			this.montante += montante;
		}
	}
	public float getComissao() {
		return comissao;
	}
	/*public void setComissao(float comissao) {
		this.comissao = comissao;
	}*/
	public int getNroVendas() {
		return nroVendas;
	}
	public void setNroVendas(int nroVendas) {
		if(nroVendas < 0 && this.nroVendas == 0) {
			this.nroVendas = 0;
		}else {
			this.nroVendas += nroVendas;
		}
	}
	public void registrarVenda(int val) {
		setNroVendas(val);
	}
	public void calComissaoVenda(float val) {
		float auxCont;
		auxCont  = this.comissao*val;
		setMontante(auxCont);
	}
}
