
public class ContaCorrente {
	protected String cpf;
	protected float saldoConta;
	protected float saldoAplicacao;
	
	public ContaCorrente (String cpf, float saldoConta,float saldoAplicacao) { 
		setCpf(cpf);
		setSaldoConta(saldoConta);
		setSaldoAplicacao(saldoAplicacao);
	}
	public ContaCorrente (String cpf) {
		setCpf(cpf);
		saldoConta = 0;
		saldoAplicacao = 0;
	}
	
	
	public String getCpf() {
		return cpf;
	}
	public void setCpf(String cpf) {
		this.cpf = cpf;
	}
	public float getSaldoConta() {
		return saldoConta;
	}
	public void setSaldoConta(float saldoConta) {
		if (saldoConta >= 0)
			this.saldoConta = saldoConta;
		
		else
			System.out.println("Saldo negativo não autorizado.");
	}
	public float getSaldoAplicacao() {
		return saldoAplicacao;
	}
	public void setSaldoAplicacao(float saldoAplicacao) {
		if (saldoAplicacao >= 0)
			this.saldoAplicacao = saldoAplicacao;
		else
			System.out.println("Saldo negativo não autorizado.");
	}
	
	public void addSaldo (float addSaldo) {
		float currentSaldo = 0;
		currentSaldo = saldoConta + addSaldo;
		setSaldoConta(currentSaldo);
	}
	public void withdrawSaldo (float withdrawSaldo) {

		float currentSaldo = 0;
		currentSaldo = (float) (saldoConta - withdrawSaldo*1.005);
		setSaldoConta (currentSaldo);
	}
	public void insertAplicacao (float insertAplicacao) {
		if (insertAplicacao < 1000)
			System.out.println("Valor para aplicação deve ser maior que R$1000,00");
		else {
			float currentSaldo = saldoConta - insertAplicacao;
			setSaldoConta (currentSaldo);
			float currentSaldoAplicacao = getSaldoAplicacao();
			currentSaldoAplicacao += insertAplicacao;
			setSaldoAplicacao(currentSaldoAplicacao);
			
		}
	}
	public void withdrawAplicacao (float withdrawAplicacao) {
		float currentSaldoAplicacao = getSaldoAplicacao();
		float currentSaldoConta = getSaldoConta();
		currentSaldoAplicacao -= withdrawAplicacao;
		if (currentSaldoAplicacao >= 0) {
			setSaldoAplicacao(currentSaldoAplicacao);
			currentSaldoConta += withdrawAplicacao;
			setSaldoConta(currentSaldoConta);
		}
		else
			System.out.println("Valor insuficiente para ser resgatado da aplicação.");
	}
}