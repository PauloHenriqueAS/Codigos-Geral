
public class ClienteEspecial extends ContaCorrente {
	
	protected float operationalTax;

	public ClienteEspecial(String cpf, float saldoConta,float saldoAplicacao, float operationalTax) {
		super(cpf, saldoConta, saldoAplicacao);
		setOperationalTax(operationalTax);
	}	
	public float getOperationalTax() {
		return operationalTax;
	}
	public void setOperationalTax(float operationalTax) {
		if (operationalTax > 0 && operationalTax <= 100)
			this.operationalTax = operationalTax;
	}
	public void withdrawSaldo (float withdrawSaldo) { //overwrites superclass when ClienteEspecial 
		float currentSaldoConta;
		currentSaldoConta = super.getSaldoConta();
		float currentSaldo = (float) (currentSaldoConta - withdrawSaldo*(1 + operationalTax/100)); 
		setSaldoConta (currentSaldo);

	}
}
