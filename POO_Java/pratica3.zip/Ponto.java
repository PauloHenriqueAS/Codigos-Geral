package atividade3;

public class Ponto {
	private float pontoX;
	private float pontoY;
	
	
	public float getPontoX() {
		return pontoX;
	}
	
	public void setPontoX(float pontoX) {
		if (pontoX <= 0) {
			this.pontoX = 0;
		}else{
			this.pontoX = pontoX;
		}
	}
	
	public float getPontoY() {
		return pontoY;
	}
	
	public void setPontoY(float pontoY) {
		if(pontoY <= 0) {
			this.pontoY = 0;
		}else {
			this.pontoY = pontoY;
		}
	}
	
	public float euclidiana(float x1, float x2, float y1, float y2) {
		float p1, p2, z;
		p1 = (x1-x2)*(x1-x2);
		p2 = (y1-y2)*(y1-y2);
		z = p1 + p2;
		Math.sqrt(z);
		
		return z;
	}
	
}
