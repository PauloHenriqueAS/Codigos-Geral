package atividade3;

public class testaPonto {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Ponto pts = new Ponto();
		float x, y, z;
		
		pts.setPontoX(4);
		//pts.x = 5;
		pts.setPontoY(2);
		x = pts.getPontoX();
		y = pts.getPontoY();
		z = pts.euclidiana(4, 3, 2, 6);
		System.out.println("X = "+x);
		System.out.println("Y = "+y);
		System.out.println("Distância Euclidiana = "+z);
	}

}
