package produto;

public class Produto {
	int codProduto;
	String nameProduto;
	float priceProduto[] = new float [5];
	
	public void setCod(int a) {
		codProduto = a;
		
	}
	
	public void setName(String b) {
		nameProduto = b;
		
	}
	
	public void setPrice(float c[]) {
		priceProduto = c;
	}
	
	public void setPricePos(int pos, float c) {
		priceProduto[pos-1] = c;
	}
	
	public int getCod() {
		return codProduto;
	}
	
	public String getName() {
		return nameProduto;
	}
	
	public float[] getPrice() {
		return priceProduto;
	}
	
	public float highestPrice() {
		float aux = 0;
		for (float num: priceProduto)
			if (num > aux)
				aux = num;
		return aux;
		
	}
	
	public float lowestPrice() {
		float aux = Float.MAX_VALUE;
		for (float num: priceProduto)
			if (num < aux)
				aux = num;
		return aux;
		
	}
	
	public float averagePrice() {
		int aux = 0;
		for(float num: priceProduto)
			aux += num;
		
		return aux/5;
		
	}

}
