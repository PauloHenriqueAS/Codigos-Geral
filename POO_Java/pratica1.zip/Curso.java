package curso;

public class Curso {

	String nomeCurso;
	int notas [] = new int[10];
	
	
	public void alteraNomeCurso(String a) {
		nomeCurso = a;
		
	}

	public void alteraNota(int b[]) {
		for (int i = 0; i < 10; i++)
		{
			notas[i] = b[i];
		}
		
	}
	
	public void alteraNotaPos(int pos, int c) {
		notas [pos-1] = c;
		
	}
	
	public String obtemNomeCurso() {
		return nomeCurso;
		
	}
	
	public int[] obtemNotas() {
		return notas;
		
	}
	
	public float calcMedia() {
		int aux = 0;
		for (int i = 0; i < 10; i++)
		{
			aux += notas[i];
		}
		
		return aux/10;
		
	}
	
	public int maiorNota() {
		int aux =0;
		for (int i = 0; i<10; i++)
		{
			if (notas[i] > aux)
			{
				aux = notas[i];
			}
		}
		return aux;
	}
	
}
