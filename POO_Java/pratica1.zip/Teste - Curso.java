package curso;

public class Teste {

	public static void main(String[] args) {
		Curso curso = new Curso();
		curso.nomeCurso = "Curso de Java"; //Atributo Nome Curso
		
		int notas[] = {60, 50, 60, 75, 65, 75, 45, 60, 80, 85};
		curso.alteraNota(notas);
		
		System.out.println(curso.obtemNomeCurso()); //M�todo Obter Atributo Nome Curso
		notas = curso.obtemNotas(); //M�todo Obter Notas
		for (int i = 0; i< 10; i++)
			System.out.print(notas[i] + " ");
		
		System.out.println("\n");
		curso.alteraNotaPos(2, 68); //M�todo Altera Nota na posi��o
		for (int i = 0; i< 10; i++)
			System.out.print(notas[i] + " ");
		
		System.out.println("\n");
		System.out.println("M�dia: " + curso.calcMedia()); //C�lculo da M�dia das Notas
		System.out.println("Maior Nota: " + curso.maiorNota()); //C�lculo da Maior Nota
		
		System.out.println("\n");
		curso.alteraNomeCurso("Curso de Java Alterado"); //M�todo Altera Nota
		System.out.println(curso.obtemNomeCurso());
		
	}

}
