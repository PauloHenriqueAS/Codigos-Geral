package produto;

public class Teste {

	public static void main(String[] args) {
		Produto produto = new Produto();
		produto.setCod(5);
		produto.setName("Produto 1");
		float price[] = {1, 2, 3, 4, 5};
		float auxPrice[] = new float[5];
		produto.setPrice(price);
		
		System.out.println("C�digo: " + produto.getCod());
		System.out.println("Nome: " + produto.getName());
		auxPrice = produto.getPrice();
		System.out.print("Pre�o: ");
		for (float num: auxPrice)
			System.out.print(num + "   ");
		
		System.out.print("\n Pre�o: ");
		produto.setPricePos(2, 50);
		for (float num: auxPrice)
			System.out.print(num + "   ");
		
		System.out.println("\n");
		System.out.println("Maior Pre�o: " + produto.highestPrice());
		System.out.println("Menor Pre�o: " + produto.lowestPrice());
		System.out.println("Pre�o M�dio: " + produto.averagePrice());
		
	}

}
