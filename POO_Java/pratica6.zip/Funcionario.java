package pratica6;

public class Funcionario extends Pessoa{
	protected double salarioBase;
	
								/*Construtor*/
	public Funcionario(String nomeP, String cpfP, String sexoP, int idadeP, double salBase) {
		super(nomeP, cpfP, sexoP, idadeP);
		setSalarioBase(salBase);
	}

	public double getSalarioBase() {
		return salarioBase;
	}
	public void setSalarioBase(double salarioBase) {
		if(salarioBase >= 0)
			this.salarioBase = salarioBase;
		else
			System.out.println("Salário Base Inválido! ");
	}
	
}
