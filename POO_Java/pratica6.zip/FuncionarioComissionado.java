package pratica6;

public class FuncionarioComissionado extends Funcionario{
	private double salarioMensal;
	private double comissoes;
	
								/*Construtor*/
	
	public FuncionarioComissionado(String nomeP, String cpfP, String sexoP, int idadeP, double salBase, double salMensal, double comissao) {
		super(nomeP, cpfP, sexoP, idadeP, salBase);
		setComissoes(comissao);
		setSalarioMensal(salMensal);
	}

	public double getSalarioMensal() {
		return salarioMensal;
	}
	public void setSalarioMensal(double salarioMensal) {
		if(salarioMensal >= 0)
			this.salarioMensal = salarioMensal;
		else
			System.out.println("Salário Mensal Inválido! ");
	}
	public double getComissoes() {
		return comissoes;
	}
	public void setComissoes(double comissoes) {
		if(comissoes >= 0)
			this.comissoes = comissoes;
		else
			System.out.println("Comissão Inválida! ");
	}
	public void aumentaComissao(double val) {
		val += getComissoes();
		setComissoes(val);
	}
	
	public void calculaSalarioMensal() {
		double val;
		val = super.getSalarioBase() + getComissoes();
		setSalarioMensal(val);
	}
	public void zerarComissoes() {
		setComissoes(0);
	}
}
