package pratica6;
import java.util.Scanner;

public class Testa {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Funcionario f[] = new Funcionario[5];
		Scanner sc = new Scanner(System.in);
		int opc;
		
		for(int i=0; i<5; i++) {
			System.out.println("Deseja Cadastrar um funcionario comissionado ou noturno? ");
			System.out.println("Comissionado = 1 | Noturno = 0 ");
			opc = sc.nextInt();
			
			if(opc == 1) {
				System.out.print("Digite o nome do funcionário ");
				String nome = sc.next();
				System.out.print("Digite o cpf do funcionário ");
				String cpf = sc.next();
				System.out.print("Digite o sexo do funcionário ");
				String sexo = sc.next();
				System.out.print("Digite a idade do funcionário ");
				int idade = sc.nextInt();
				System.out.print("Digite o salario base do funcionário ");
				double salBase = sc.nextDouble();
				System.out.print("Digite o salario mensal do funcionário ");
				double salMen = sc.nextDouble();
				System.out.print("Digite a comissão do funcionário ");
				double com = sc.nextDouble();
				f[i] = new FuncionarioComissionado(nome, cpf, sexo, idade, salBase, salMen, com);
			}
			if(opc == 0) {
				System.out.print("Digite o nome do funcionário ");
				String nome = sc.next();
				System.out.print("Digite o cpf do funcionário ");
				String cpf = sc.next();
				System.out.print("Digite o sexo do funcionário ");
				String sexo = sc.next();
				System.out.print("Digite a idade do funcionário ");
				int idade = sc.nextInt();
				System.out.print("Digite o salario base do funcionário ");
				double salBase = sc.nextDouble();
				System.out.print("Digite o salario mensal do funcionário ");
				double salMen = sc.nextDouble();
				System.out.print("Digite o adicional do funcionário ");
				double adicional = sc.nextDouble();
				System.out.print("Digite o número de noites trabalhadas do funcionário ");
				int noites = sc.nextInt();
				f[i] = new FuncionarioNoturno(nome, cpf, sexo, idade, salBase, salMen, adicional, noites);
			}
		}
		sc.close();
	}

}
