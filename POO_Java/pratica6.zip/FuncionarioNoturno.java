package pratica6;

public class FuncionarioNoturno extends Funcionario{
	private double salarioMensal;
	private double adicionalTrabalhoNoturno;
	private int nroNoitesTrabalhadas;
	
							/*Construtor*/
	public FuncionarioNoturno(String nomeP, String cpfP, String sexoP, int idadeP, double salBase, double salMensal, double addNoturno, int nroNoites) {
		super(nomeP, cpfP, sexoP, idadeP, salBase);
		setSalarioMensal(salMensal);
		setAdicionalTrabalhoNoturno(addNoturno);
		setNroNoitesTrabalhadas(nroNoites);
	}

	public double getSalarioMensal() {
		return salarioMensal;
	}

	public void setSalarioMensal(double salarioMensal) {
		if(salarioMensal >= 0)
			this.salarioMensal = salarioMensal;
		else
			System.out.println("Salário Mensal Inválido! ");
	}

	public double getAdicionalTrabalhoNoturno() {
		return adicionalTrabalhoNoturno;
	}

	public void setAdicionalTrabalhoNoturno(double adicionalTrabalhoNoturno) {
		if(adicionalTrabalhoNoturno >= 0)
			this.adicionalTrabalhoNoturno = adicionalTrabalhoNoturno;
		else
			System.out.println("Adicional Inválido! ");
	}

	public int getNroNoitesTrabalhadas() {
		return nroNoitesTrabalhadas;
	}

	public void setNroNoitesTrabalhadas(int nroNoitesTrabalhadas) {
		if(nroNoitesTrabalhadas >= 0)
			this.nroNoitesTrabalhadas = nroNoitesTrabalhadas;
		else
			System.out.println("Número de Noites Inválido! ");
	}
	
	public void calculaSalarioMensal() {
		double val;
		val = super.getSalarioBase() + getAdicionalTrabalhoNoturno()*getNroNoitesTrabalhadas();
		setSalarioMensal(val);
	}
	public void aumentaNroNoites(int val) {
		val += getNroNoitesTrabalhadas();
		setNroNoitesTrabalhadas(val);
	}
	public void aumentaAdicional(double add) {
		add += getAdicionalTrabalhoNoturno();
		setAdicionalTrabalhoNoturno(add);
	}
	public void zerarAdicional() {
		setAdicionalTrabalhoNoturno(0);
	}
	public void zerarNroNoites() {
		setNroNoitesTrabalhadas(0);
	}
}
