%%%Exercicio-4
subconjunto_possivel([], []).
subconjunto_possivel(Subconj,[X|Conj]):- subconjunto_possivel(Subconj,Conj).
subconjunto_possivel([X|Subconj],[X|Conj]):- subconjunto_possivel(Subconj, Conj).

subconjunto_auxiliar([], _).
subconjunto_auxiliar([X|Subconj], Conj):- member(X, Conj), subconjunto_auxiliar(Subconj, Conj).

subconj(Subconj, Conj):- var(Subconj), subconjunto_possivel(Subconj, Conj).
subconj(Subconj, Conj):- not(var(Subconj)), subconjunto_auxiliar(Subconj, Conj).

conjpotencia(Conj, Conjmaior):- setof(Subconj,subconj(Subconj,Conj),Conjmaior)
