%%%Exercicio-9

termoaterrado(X) :- not(var(X)), X =..[_|Y], termoaterradoLista(Y).
termoaterradoLista([]) :- !.
termoaterradoLista([X|Xs]) :- termoaterrado(X), termoaterradoLista(Xs).

