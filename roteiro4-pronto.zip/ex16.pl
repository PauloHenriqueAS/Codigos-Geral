%%%Exercicio-16
classe(Numero,positivo):- Numero > 0.
classe(0,zero).
classe(Numero, negativo):- Numero < 0.

/*
verifica se Numero e maior que zero
se 0 = true
verifica se Numero e menor que 0
Resumo -> verifica se um número  é positivo, 0 ou negativo.
*/

classe(Numero,positivo):− Numero > 0,!.
classe(0,zero):- !.
classe(Numero, negativo):− Numero < 0.
