%%%Exercicio-13
nu(X,X):- !, fail.
nu(X,Y):- \+ X = Y.
nu(X,Y):- not(X = Y).
nu(_,Y):- !, fail.
nu(_,_).

/*
?- nu(foo,foo).
false

?- nu(foo,blob).
true
true
true

?- nu(foo,X).
false
*/
