%%%Exercicio-1
s --> sn, sv.
sn --> det, n.
sv --> v, sn.
sv --> v.
det --> [o].
det --> [a].
n --> [mulher].
n --> [homem].
v --> [bate].

/*trace.
s([o, mulher, bate, o, homem],[]).
 Call:s([o, mulher, bate, o, homem], [])
 Call:sn([o, mulher, bate, o, homem], _5344)
 Call:det([o, mulher, bate, o, homem], _5346)
 Exit:det([o, mulher, bate, o, homem], [mulher, bate, o, homem])
 Call:n([mulher, bate, o, homem], _5344)
 Exit:n([mulher, bate, o, homem], [bate, o, homem])
 Exit:sn([o, mulher, bate, o, homem], [bate, o, homem])
 Call:sv([bate, o, homem], [])
 Call:v([bate, o, homem], _5348)
 Exit:v([bate, o, homem], [o, homem])
 Call:sn([o, homem], [])
 Call:det([o, homem], _5350)
 Exit:det([o, homem], [homem])
 Call:n([homem], [])
 Exit:n([homem], [])
 Exit:sn([o, homem], [])
 Exit:sv([bate, o, homem], [])
 Exit:s([o, mulher, bate, o, homem], [])
*/
