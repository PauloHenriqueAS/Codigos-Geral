%%%Exercicio-14
unificavel([X|Xs],Termo,Z):- \+ X = Termo,!,unificavel(Xs,Termo,Z).
unificavel([X|Xs],Termo,[X|Z]):- unificavel(Xs,Termo,Z).
unificavel([],Termo,[]).
