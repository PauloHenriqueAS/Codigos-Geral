%%%Exercicio-8

termo(_,Y) :- Y=termo.
variavel(X, Y) :- var(X), Y=variavel.
atomo(X, Y) :- atom(X), Y=atomo.
constante(X, Y) :- atomic(X), Y=constante.
numero(X,Y) :- number(X), Y=numero. 
termo_simples(X, Y):- nonvar(X), functor(X,_,Z), Z == 0, Y=termo_simples.
termo_complexo(X, Y):-nonvar(X), functor(X,_,Z), Z >0, Y=termo_Complexo.


tipotermo(X,Y) :- atomo(X, Y); constante(X, Y); variavel(X,Y);
                  termo_simples(X,Y); termo_complexo(X,Y);
                  termo(X,Y); numero(X,Y).

/*var, atom, atomic, number, nonvar, functor -> presente na linguagem-documentacacao*/
