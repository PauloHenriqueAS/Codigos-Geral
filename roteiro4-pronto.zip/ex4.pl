%%%Exercicio-4
%cangu(V,R,Q) −−> ru(V,R), salta(Q,Q), {marsupial(V,R,Q)}.
cango(V,R,Q,X,Z) :- ru(V,R,X,Y), pula(Q,Q,Y,Z), marsupial(V,R,Q).
