%%%Exercicio-17
positivo(X, Resul) :- X>=0, Resul is X.
negativo(Y, Resul) :- not(Y>=0), Resul is Y.

divide([],[],[]).
divide([X|Xs],[Y|Ys], Z) :- positivo(X, Y), !, divide(Xs,Ys,Z).
divide([X|Xs],Y, [Z|Zs]) :- negativo(X, Z), divide(Xs,Y,Zs).