%%%Exercicio-5
s(Num, s(Num, NPlu, VPlu)) --> nplu(Num, NPlu), vplu(Num, VPlu).

nplu(Num, nplu(Num, DET, N)) --> det(Num, DET), n(Num, N).

vplu(Num, vplu(Num, V, NPlu)) --> v(Num, V), nplu(_, NPlu).

vplu(Num, vplu(Num, V)) --> v(Num, V).

det(Num, det(Num, Palavra)) --> [Palavra], {lex(Palavra, Num, det)}.

n(Num, n(Num, Palavra)) --> [Palavra], {lex(Palavra, Num, n)}.

v(Num, v(Num, Palavra)) --> [Palavra], {lex(Palavra, Num, v)}.
