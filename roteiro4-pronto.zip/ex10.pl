%%%Exercicio-10

:- op(300,xfx, [sao, eh_um]).
:- op(300,fx, gosta_de).
:- op(200,xfy, e).
:- op(100,fy, famoso).

/*
?- X eh_um bruxo.
                %%%correto OperadorPrincipal = eh_um

?- harry e ron e hermione sao amigos.
                %%%correto OperadorPrincipal = sao

?- harry eh_um mago e gosta_de quadribol.
                %%%errado OperadorPrincipal = eh_um
                %%%correto = (harry eh_um mago) e gosta_de quadribol.

?- dumbledore eh_um famoso famoso mago.
                %%%correto OperadorPrincipal = eh_um


%%%Reescrevendo com parênteses
?- X eh_um bruxo.
                
?- (harry e ron e hermione) sao amigos.
                
?- (harry eh_um mago) e gosta_de quadribol.
                
?- (dumbledore eh_um famoso) famoso mago.
*/
