%%%Exercicio-3
s --> sn, sv.
sn --> det, n.
sn -->detplural, nplural.

sv --> v, sn.
sv --> v.

sv --> vplural, sn.
sv --> vplural.

det --> [o].
detplural --> [os].
det --> [a].

n --> [mulher].
n --> [homem].
nplural --> [homens].

v --> [bate].
vplural --> [batem].
