%%%Exercicio-2
s(Conta) --> xs(Conta), ys(Conta), zs(Conta).
xs(0) --> [].
xs(suc(Conta)) --> [x], xs(Conta).

ys(0) --> [].
ys(suc(Conta)) --> [y], ys(Conta).

zs(0) --> [].
zs(suc(Conta)) --> [z], zs(Conta).

/*
?- s(C,S,[]).
        C = 0,
	S = []
	C = suc(0),
	S = [x, y, z]
	C = suc(suc(0)),
	S = [x, x, y, y, z, z]
	C = suc(suc(suc(0))),
	S = [x, x, x, y, y, y, z, z, z]
	C = suc(suc(suc(suc(0)))),
	S = [x, x, x, x, y, y, y, y, z, z, z, z]
	C = suc(suc(suc(suc(suc(0))))),
	S = [x, x, x, x, x, y, y, y, y, y, z, z, z, z, z].
*/
