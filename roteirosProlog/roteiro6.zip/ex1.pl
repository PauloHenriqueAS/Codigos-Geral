%%%Exercicio-1
:-dynamic empr/3.
empr(carlos, 5, 7000).
empr(bruno, 3, 6000).
empr(jose, 3, 15000).
empr(roberto, 1, 3000).
empr(gustavo, 5, 5000).
empr(lucas, 1, 10000).

:- dynamic depto/2.
depto(5, gustavo).
depto(3, jose).
depto(1, lucas).

salarioMaior(Nome, Depto, SalarioF) :- empr(Nome, Depto, SalarioF),
                                       empr(Nome, Depto, Salario), 
                                       depto(Departamento, Gerente), 
                                       salarioF > salario.
r(X):-findall(X, salarioMaior(X),Func).

/*:-module(empr, [empr/3]). 
 
:-use_module(library(persistency)).
 
:-persistent
           empr(nome: string,
                depto: positive_integer,
                salario: positive_integer
               ).
 
:- initialization(db_attach('tbl_empr.pl',[])).
 
insere(Nome, Depto, Salario):-
                              with_mutex(empr,
                              assert_empr(Nome, Depto, Salario)).
 
remove(Nome):-
              with_mutex(empr,
              retract_empr(Nome, _Depto, _Salario)).
 
atualiza(Nome, Depto, Salario):-
                              with_mutex(empr,
                              (retractall_empr(Nome, _Depto, _Salario),
                              assert_empr(Nome, Depto, Salario))).
                    
sincroniza :- db_sync(gc(always)).

:-module(depto, [depto/2]). 
 
:-use_module(library(persistency)).
 
:-persistent
           depto(depto: positive_integer,
                 nome: string
                ).
 
:- initialization(db_attach('tbl_depto.pl',[])).
 
insere(Depto,Nome):-
                    with_mutex(depto,
                    assert_depto(Depto,Nome)).
 
remove(Nome):-
              with_mutex(depto,
              retract_depto(_Depto, Nome)).
 
atualiza(Depto,Nome):-
                      with_mutex(depto,
                      (retractall_depto(_Depto, Nome),
                      assert_depto(Depto,Nome))).
                    
sincroniza :- db_sync(gc(always)).*/

