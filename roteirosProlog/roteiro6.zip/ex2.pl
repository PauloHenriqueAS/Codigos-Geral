%%%Exercicio-2
/*
paı́s(X)  % X é um paı́s
mar(X)   % X é um mar
população(X,Y)   % X tem a população Y
fronteira(X, Y)  % X faz fronteira com Y
*/
:- dynamic pais/1.
:- dynamic banhado/1.
:- dynamic população/2.
:- dynamic fronteira/2.

pais(turquia).
pais(georgia).
pais(russia).
pais(china).
pais(india).
mar(mediterraneo).

banhado(turquia,mediterraneo).

populacao(turquia,82).
populacao(georgia,3.73).
populacao(russia,144.5).
populacao(china,1393).
populacao(india,1353).

fronteira(turquia,georgia).
fronteira(georgia,turquia).
fronteira(georgia,russia).
fronteira(russia,georgia).
fronteira(russia,china).
fronteira(china,russia).
paisBanhado(X) :- pais(X), banhado(X, Y), fronteira(X,Z), populacao(Z,W), W >1353.
