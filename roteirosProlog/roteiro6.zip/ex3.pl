%%%Exercicio-3
:- use_module(library(http/thread_httpd)).
:- use_module(library(http/http_dispatch)).
:- use_module(library(http/html_write)).

servidor(Porta) :-
http_server(http_dispatch, [port(Porta)]).
:- http_handler(root(.), pagina, []).

pagina(_Pedido) :-
    reply_html_page(
                    [head(title('Uma Página HTML com tabela'))],
                    [h1('Como escrever uma página web'),
                    p('Começe pelo inı́cio, desenvolva o meio e termine no fim.'),
                    p('Escreva sites para pessoas famosas: '),
                     table([tr([ th('Nome  '),
                                 th('Sobrenome'),
                                 th('Cidade')
                          ]),
                            tr([td('Roberto  '),
                                td('Carlos Braga  '),
                                td('Cachoeiro de Itapemirim')
                          ]),
                            tr([td('Fernanda '),
                                td('Barbosa Takai '),
                                td('Serra do Navio')
                          ]),
                            tr([td('Davi Alexandre  '),
                                td('Magalhaes de Almeida  '),
                                td('Ribeirao Preto')
                          ])
                     ]),
                    footer([p('Autor: Paulo Henrique')])
                    ]).
