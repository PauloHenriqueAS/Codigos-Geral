%%%Exercicio-16
remove(X,[X|Ys], Ys).
remove(X,[H|Ys], [H|Y1]) :- remove(X,Ys,Y1).

