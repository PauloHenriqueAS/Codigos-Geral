%%%Exercicio-19
remove(X, [X|Xs], Xs).
remove(X, [Y|Ys], [Y|Y1]):- remove(X, Ys, Y1).

permutacao([], []).
permutacao(Xs,[Y|Zs]) :- remove(Y,Xs,Ys), permutacao(Ys,Zs).

tam([],0).
tam([_|Xs],Ntam) :- tam(Xs,Tamanho), Ntam is Tamanho+1.


npermutacoes(0, []).
npermutacoes(1, [_]).
npermutacoes(M, [X|Xs]):- tam([X|Xs], Y), npermutacoes(Ms,Xs), M is Y*Ms. 

