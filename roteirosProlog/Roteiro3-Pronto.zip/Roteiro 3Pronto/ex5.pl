%%%Exercicio-5
pertence(X,[X|_]).
pertence(X,[_|Xs]) :- pertence(X,Xs).

subconjunto([],_).
subconjunto([X|Xs],Lista) :- pertence(X,Lista), subconjunto(Xs,Lista).
