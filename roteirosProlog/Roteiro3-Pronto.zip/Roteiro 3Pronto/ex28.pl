%%%Exercicio-28
ocorrencias(_,[],0).
ocorrencias(X,[X|Ys],Val):- ocorrencias(X,Ys,W), Val is W+1.
ocorrencias(X,[Y|Ys],Val):- not(X=Y), ocorrencias(X,Ys,Val).
