%%%Exercicio-37
prop --> [p].
prop --> [q].
prop --> [r].
%%%nao
prop --> [nao],prop.
%%%e
prop --> ['('],prop,[e],prop,[')'].
%%%ou
prop --> ['('],prop,[ou],prop,[')'].
%%%implica
prop --> ['('],prop,[implica],prop,[')'].

