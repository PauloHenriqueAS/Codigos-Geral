%%%Exercicio-18
remove(X, [X|Xs], Xs).
remove(X, [Y|Ys], [Y|Y1]):- remove(X, Ys, Y1).

permutacao([], []).
permutacao(Xs,[Y|Zs]) :- remove(Y,Xs,Ys), permutacao(Ys,Zs).

/* 
%%% A)
permutacao([a,m,o,r], Opcanagrama).
	Opcanagrama = [a, m, o, r] ;
	Opcanagrama = [a, m, r, o] ;
	Opcanagrama = [a, o, m, r] ;
	Opcanagrama = [a, o, r, m] ;
	Opcanagrama = [a, r, m, o] ;
	Opcanagrama = [a, r, o, m] ;
	Opcanagrama = [m, a, o, r] ;
	Opcanagrama = [m, a, r, o] ;
	Opcanagrama = [m, o, a, r] ;
	Opcanagrama = [m, o, r, a] ;
	Opcanagrama = [m, r, a, o] ;
	Opcanagrama = [m, r, o, a] ;
	Opcanagrama = [o, a, m, r] ;
	Opcanagrama = [o, a, r, m] ;
	Opcanagrama = [o, m, a, r] ;
	Opcanagrama = [o, m, r, a] ;
	Opcanagrama = [o, r, a, m] ;
	Opcanagrama = [o, r, m, a] ;
	Opcanagrama = [r, a, m, o] ;
	Opcanagrama = [r, a, o, m] ;
	Opcanagrama = [r, m, a, o] ;
	Opcanagrama = [r, m, o, a] ;
	Opcanagrama = [r, o, a, m] ;
	Opcanagrama = [r, o, m, a] .

%%% B)
permutacao([Sergio, Adriano, Fabiola], Opcposi).
	Opcposi = [Sergio, Adriano, Fabiola] ;
	Opcposi = [Sergio, Fabiola, Adriano] ;
	Opcposi = [Adriano, Sergio, Fabiola] ;
	Opcposi = [Adriano, Fabiola, Sergio] ;
	Opcposi = [Fabiola, Sergio, Adriano] ;
	Opcposi = [Fabiola, Adriano, Sergio] ;
	false.
*/


