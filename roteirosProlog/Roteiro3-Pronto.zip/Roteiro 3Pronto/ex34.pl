%%%Exercicio-34
s --> sn, sv.
sn --> det, n.
sv --> v, sn.
sv --> v.

det --> [o].
det --> [a].

n --> [homem].
n --> [mulher].
n --> [bola].

v --> [chuta].

