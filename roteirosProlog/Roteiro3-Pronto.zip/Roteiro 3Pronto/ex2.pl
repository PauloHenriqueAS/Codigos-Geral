%%%Exercicio-2

intercala1([X],[Y],[X,Y]).
intercala1([X|Xs],[Y|Ys],[X,Y|Lista]) :- intercala1(Xs,Ys,Lista).
