%%%Exercicio-11

soma(X,Y,Z) :- Z is X+Y.

/*
soma(4,5,9).
true.

soma(4,6,12).
false.
*/
