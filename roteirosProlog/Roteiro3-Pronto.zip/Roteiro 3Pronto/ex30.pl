%%%Exercicio-30
soma_acum(X,Y) :- recursao(X,Y,0).
recursao([],[],_).
recursao([X|Xs],[Y|Ys],Z) :- Y is Z+X, recursao(Xs,Ys,Y).
