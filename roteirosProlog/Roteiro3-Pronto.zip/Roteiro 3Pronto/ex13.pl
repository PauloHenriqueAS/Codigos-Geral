%%%Exercicio-13
minAcum([],A,A).
minAcum([H|T],A,Min) :- H < A, minAcum(T,H,Min).
minAcum([H|T],A,Min) :- H >= A, minAcum(T,A,Min).

/*
minAcum([1,0,5,4],0,M).
*/
