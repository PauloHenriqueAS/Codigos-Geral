%%%Exercicio-21
fat(0,1) :- !.
fat(X,Resu) :- X1 is X-1, fat(X1,Resu1), Resu is X * Resu1.
ncombinacoes(M,P,N) :- length(M, Tam), fat(Tam, X), fat(P, Y), Aux1 is Tam-P, fat(Aux1,Aux2), N1 is Y*Aux2, N is X/N1.
