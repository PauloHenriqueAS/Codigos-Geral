%%%Exercicio-6
pertence(X,[X|_]).
pertence(X,[_|Xs]) :- pertence(X,Xs).

subconjunto([],_).
subconjunto([X|Xs],Lista) :- pertence(X,Lista), subconjunto(Xs,Lista).

superconjunto(L1,L2) :- subconjunto(L2,L1).
