%%%Exercicio-12
soma(X,Y) :- Y is X+1.

somaUm([],[]).
%%%somaUm([Y|Ys], [X|Xs]) :- X is Y+1, somaUm(Ys, X).
somaUm([Y|Ys], [X|Xs]) :-  soma(Y, X), somaUm(Ys, Xs).


/*
somaUm([1,2,7,2],X).
X = [2,3,8,3].
*/
