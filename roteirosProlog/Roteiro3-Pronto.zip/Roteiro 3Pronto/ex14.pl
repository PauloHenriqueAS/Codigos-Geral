%%%Exercicio-14
mult1(X,Y, Resul) :- Resul is X*Y. 

multiEsc(_, [], []).
multiEsc(X, [L1|L2], [Y|Ys]) :- mult1(X, L1, Y), multiEsc(X, L2, Ys).
                                
/*
multiEsc(3,[2,7,4],Resultado).
Resultado = [6,21,12].
*/
