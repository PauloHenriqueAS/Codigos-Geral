%%%Exercicio-20
combinacao(0,_,[]).
combinacao(N,[X|Xs],[X|Ys]) :- N>0, Ns is N-1, combinacao(Ns,Xs,Ys).
combinacao(N,[_|Xs], Ys) :- N>0, combinacao(N,Xs,Ys).

combinacao2(Ns,Xs,Ns1,Ys,Resul) :- combinacao(Ns, Xs, W), combinacao(Ns1, Ys, Z), append(W, Z, Resul).
