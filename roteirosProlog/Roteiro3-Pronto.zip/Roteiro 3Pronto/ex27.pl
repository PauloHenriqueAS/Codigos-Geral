%%%Exercicio-27
%%%A)
disjunto([], _) :- !.
disjunto([X1|_], L) :- member(X1,L), !, fail.
disjunto([_|Xs], L) :- disjunto(Xs, L).

%%%B)
uniao([], L, L) :- !.
uniao(L, [], L) :- !.
uniao([X|Xs], L, L2) :-	member(X, L),!,	uniao(Xs, L, L2).
uniao([X|Xs], L, [X|L2]) :- uniao(Xs, L, L2).

%%%C)
intersecao([], _, []) :- !.
intersecao(_, [], []) :- !.
intersecao([X|Xs], L, [X|L2]) :- member(X, L),!,intersecao(Xs, L, L2).
intersecao([X|Xs], L, L2) :- \+ member(X, L), intersecao(Xs, L, L2).
	
%%%D)
pertence(X,[X|_]) :- !.
pertence(X,[_|Ys]) :- pertence(X,Ys).
nao_pertence(_,[]) :- !.
nao_pertence(X,[Y|Ys]) :- X \= Y, nao_pertence(X,Ys).

diferenca([], _, []).
diferenca([X|Xs], L2, D) :- pertence(X, L2), diferenca(Xs, L2, D).
diferenca([X|Xs], L2, [X|D]) :- nao_pertence(P, L2), diferenca(Xs, L2, D).
