%%%Exercicio-15
prodEsc([],[],0).
prodEsc([X|Xs], [Y|Ys], R):- Aux1 is (X*Y), prodEsc(Xs, Ys, Aux2), R is Aux2 + Aux1.
