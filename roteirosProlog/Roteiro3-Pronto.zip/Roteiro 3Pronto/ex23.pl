%%%Exercicio-23
concatena([],L, L).
concatena([X|Xs], Val, [Y|Ys] ) :- concatena(Xs, Val, Ys).

combinacoes(0, _, []).
combinacoes(X, Conj, [Elem|Calda]) :- Rt is X-1,  concatena(_, [Elem|Resto], Conj), combinacoes(Rt, Resto, Calda).



