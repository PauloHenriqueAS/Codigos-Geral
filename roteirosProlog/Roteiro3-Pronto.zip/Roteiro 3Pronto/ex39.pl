%%%Exercicio-39
s --> a,b.
s --> a,s,b.

a --> [a].
b --> [b].
