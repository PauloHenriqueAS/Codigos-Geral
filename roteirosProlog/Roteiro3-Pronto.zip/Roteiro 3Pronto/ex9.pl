%%%Exercicio-9
/*
 X = 3 * 4.   X = 3*4.
 X is 3 * 4.  X = 12.
 4 is X.      erro.
 X = Y.       X = Y.
 3 is 1+2.    true.
 3 is +(1,2). true.
 3 is X+2.    erro.
 X is 1+2.    X = 3.
 1+2 is 1+2.  false.
 is(X,+(1,2)). X = 3. forma como o prolog entende
 3+2 = +(3,2).  true.
*(7,5) = 7 * 5. true
*(7,+(3,2)) = 7*(3+2).  true.
*(7,(3+2)) = 7*(3+2).  true.
*(7,(3+2)) = 7*(+(3,2)). true.
*/