%%%Exercicio-38
s --> foo,bar,wiggle.
foo --> [choo].
foo --> foo,foo.
bar --> mar,zar.
mar --> me,my.
me --> [i].
my --> [am].
zar --> blar,car.
blar --> [a].
car --> [train].
wiggle --> [toot].
wiggle --> wiggle,wiggle.

s(X,Xs) :- foo(X,Y), bar(Y,Z), wiggle(Z,Xs).
foo([choo|W],W).
foo(X,Z) :- foo(X,Y), foo(Y,Z).
bar(X,Z) :- mar(X,Y), zar(Y,Z).
mar(X,Z) :- me(X,Y), my(Y,Z).
me([i|W],W).
my([am|W],W).
zar(X,Z) :- blar(X,Y), car(Y,Z).
blar([a|W],W).
car([train|W],W).
wiggle([toot|W],W).
wiggle(X,Xs) :- wiggle(X,Y), wiggle(Y,Xs).

%X = [choo, i, am, a, train, toot]
%X = [choo, i, am, a, train, toot, toot]
%X = [choo, i, am, a, train, toot, toot, toot]
%
%
