%%%Exercicio-1
membro(X,[X|_ ]).
membro(X,[_|T]) :- membro(X,T).

/*
  trace, (membro(a,[1,2,a,b])).
    Call:membro(a, [1, 2, a, b])
    Call:membro(a, [2, a, b])
    Call:membro(a, [a, b])
    Exit:membro(a, [a, b])
    Exit:membro(a, [2, a, b])
    Exit:membro(a, [1, 2, a, b])

  trace, (membro(a,[1,2,a,b])).
    Call:membro(z, [1, 2, a, b])
    Call:membro(z, [2, a, b])
    Call:membro(z, [a, b])
    Call:membro(z, [b])
    Call:membro(z, [])
    Fail:membro(z, [])
    Fail:membro(z, [b])
    Fail:membro(z, [a, b])
    Fail:membro(z, [2, a, b])
    Fail:membro(z, [1, 2, a, b])

  trace, (membro(X,[1,2,a,b])).
    Call:membro(_3502, [1, 2, a, b])
    Exit:membro(1, [1, 2, a, b])
*/
