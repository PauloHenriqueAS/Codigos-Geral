%%%Exercicio-25
remove([],[]) :- !.
remove([X1|Xs],Lista) :-  member(X1, Xs), !,remove(Xs, Lista).
remove([X1|Xs],[X1|L1]) :- \+ member(X1, Xs), remove(Xs, L1).

sem_repeticao([],[]) :- !.
sem_repeticao([X1],[X1]) :- !.

sem_repeticao([X1,X1|Xs], Lista) :-remove([X1|Xs], Lista).
sem_repeticao([X1,Y|Xs], [X1|L1]):- Y \= X1, remove([Y|Xs], L1).
