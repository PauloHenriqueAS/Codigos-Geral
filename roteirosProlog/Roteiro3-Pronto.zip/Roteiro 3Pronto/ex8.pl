%%%Exercicio-8
concatena([],L, L).
concatena([X|Xs], Val, [Y|Ys] ) :- concatena(Xs, Val, Ys).

inverte([],[]).
inverte([X|Xs],L) :- inverte(Xs, Y), concatena(Y,[X], L).

palindromo(X) :- inverte(X,X).

/*
palindromo([r,o,d,a,d,o,r]).
true.
palindromo([a,d,r,o,g,a,d,a,g,o,r,d,a]).
true.
palindromo([e,s,s,e,n,a,o]).
false.
 */
