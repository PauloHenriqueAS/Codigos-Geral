%%%Exercicio-36
s --> x.
s --> a,d.
s --> a,s,d.
x --> [].
x --> b,b,x,c,c.
a --> [a].
b --> [b].
c --> [c].
d --> [d].
