%%%Exercicio-22

remove(X, [X|W], W).
remove(X, [Y|w], [Y|L]) :- remove(X, W, L).

arranjo(0,_,[]).
arranjo(R, Xs,[Y|Zs]) :- Rt is R-1, remove(Y,Xs,Ys), arranjo(Rt, Ys,Zs).
