%%%Exercicio-4

intercala3([X],[Y],[junta(X,Y)]).
intercala3([X|Xs],[Y|Ys],[junta(X,Y)|Lista]) :- intercala3(Xs,Ys,Lista).
