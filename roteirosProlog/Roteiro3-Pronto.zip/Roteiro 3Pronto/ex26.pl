%%%Exercicio-26
concatena([],L, L).
concatena([X|Xs], Val, [Y|Ys] ) :- concatena(Xs, Val, Ys).

sublista(Sub,Lista) :- concatena(_,Val,Lista), concatena(Sub,_,Val).

segmento([],[]) :- !.
segmento(L,Xs) :- sublista(L,Xs),!.


