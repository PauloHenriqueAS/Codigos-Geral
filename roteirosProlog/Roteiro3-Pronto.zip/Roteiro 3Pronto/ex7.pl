%%%Exercicio-7
duplicada(Lista) :- append(X, X, Lista).
