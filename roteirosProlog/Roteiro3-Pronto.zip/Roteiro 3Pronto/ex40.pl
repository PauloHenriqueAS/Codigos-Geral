%%%Exercicio-40
s --> [].
s --> a,s,b.

a --> [a].
b --> [b,b].

