%%%Exercicio-17
insere(X, Ys, [X|Ys]).
insere(X,[H|Ys], [H|Y1]) :- insere(X,Ys,Y1).
