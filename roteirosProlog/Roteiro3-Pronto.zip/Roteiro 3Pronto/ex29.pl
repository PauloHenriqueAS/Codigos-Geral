%%%Exercicio-29
ocorre([X|_],1,X).
ocorre([_|Xs],Val,X) :- Val > 1, W is Val-1, ocorre(Xs,W,X).
