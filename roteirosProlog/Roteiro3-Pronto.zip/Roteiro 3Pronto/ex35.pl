%%%Exercicio-35
s --> [].
s --> a,s.

a --> [a,a].
