%%%Exercicio-3

intercala2([X],[Y],[[X,Y]]).
intercala2([X|Xs],[Y|Ys],[[X,Y]|Lista]) :- intercala2(Xs,Ys,Lista).
