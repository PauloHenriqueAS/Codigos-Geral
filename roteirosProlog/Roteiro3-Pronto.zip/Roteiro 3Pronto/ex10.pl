%%%Exercicio-10
incrementa(X, Y) :-  X is Y-1. 
 
/*incrementa(4,5).
true.

incrementa(4,6).
false.
*/
