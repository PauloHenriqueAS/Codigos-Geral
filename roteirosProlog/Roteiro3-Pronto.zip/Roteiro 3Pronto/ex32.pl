%%%Exercicio-32
s(A-C):- sn(A-B), sv(B-C).
sn(A-C):- det(A-B), n(B-C).
sv(A-C):- v(A-B), sn(B-C).
sv(A-C):- v(A-C).

det([o|X]-X).
det([a|X]-X).

n([homem|X]-X).
n([mulher|X]-X).
n([bola|X]-X).

v([chuta|X]-X).
