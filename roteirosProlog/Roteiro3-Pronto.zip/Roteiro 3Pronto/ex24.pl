%%%Exercicio-24
fat(0,1) :- !.
fat(X,Y) :- Xt is X-1, fat(Xt,R1), R is X * R1.

narranjos(X,Y,Resu) :- fat(X,Xs), Y1 is X-Y, fat(Y1,Y2), Resu is Xs/Y2.

