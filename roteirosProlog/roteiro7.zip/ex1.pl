:- use_module(library(http/thread_httpd)).
:- use_module(library(http/http_dispatch)).
:- use_module(library(http/html_write)).
:- use_module(library(http/html_head)).
:- use_module(library(http/http_server_files)).
:- use_module(library(http/http_client)).
:- use_module(library(http/http_parameters)).

servidor(Porta) :-
    http_server(http_dispatch, [port(Porta)]).

:- http_handler(root(.), formulário , []).

formulário(_Pedido) :-
	reply_html_page(
	    title('Categoria-Produto'),
		center(
	    [ form([ action='/formulario', method='POST'],
	           [ p([],
	               [ label([for=cod],'ID:'),
		             input([name=cod, type=textarea]) ]),
		         p([],
		           [ label([for=nome],'Nome:'),
		             input([name=nome, type=textarea]) ]),
                 p([],
		           [ label([for=idade],'Idade:'),
		             input([name=idade, type=textarea]) ]),
		         p([],
		           input([name=submit, type=submit, value='Confirmar'],
                         []))
	           ])]
			   
	)).
:- http_handler('/formulario', resp(Method),
                [ method(Method),
                  methods([post]) ]).

resp(post,Pedido) :-
	reply_html_page( title('Resultado do Formulário'),
		           [ \página(Pedido) ]).

página(Pedido) -->
    {
        catch(
            http_parameters(Pedido,
                            [ 
                             cod(Id,         [integer]),
                             nome(Nome,      [string]),
							               idade(Idade,    [integer])
                            ]),
            _E, fail), !
    },
    html([ 
		       h1('Formulário'),
           h2('Os dados recebidos são:'),
           p('O Id é ~w' - Id),
           p('Seu Nome: ~w' - Nome),
           p('Sua Idade: ~w' - Idade)   
         ]).

página(_Pedido) -->
    html([ h1('Erro'),
           p('Parâmetro inválido encontrado!')
         ]).
