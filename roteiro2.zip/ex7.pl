/*(a)
    [a,b,c,d] = [a,[b,c,d]].
(b)
    [a,b,c,d] = [a|[b,c,d]].
(c)
    [a,b,c,d] = [a,b,[c,d]].
(d) 
    [a,b,c,d] = [a,b|[c,d]].
(e)
    [a,b,c,d] = [a,b,c,[d]].
(f)
    [a,b,c,d] = [a,b,c|[d]].
(g)
    [a,b,c,d] = [a,b,c,d,[]].
(h)
    [a,b,c,d] = [a,b,c,d|[]].
(i)
    [] = _.
(j)
    [] = [_].
(k)
    [] = [_|[]].

A = false
B = true
C = false
D = true
E = false
F = true
G = false
H = true
I = true
J = false
K = false
*/