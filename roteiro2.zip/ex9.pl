%%%repete([X,X|Xs]).

duasVezes([], []).
duasVezes([X|Xs], [X,X|Ys]) :-  duasVezes(Xs, Ys).