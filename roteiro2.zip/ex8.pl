trad(eins,um).
trad(zwei,dois).
trad(drei,tres).
trad(vier,quatro).
trad(fuenf,cinco).
trad(sechs,seis).
trad(sieben,sete).
trad(acht,oito).
trad(neun,nove).

tradlista([],[]).
tradlista([A|As], [P|Ps]) :- trad(A, P), tradlista(As, Ps). 