objeto(a).
objeto(b).
sobre(mesa).
sobre(X, Y) :- sobre(Y), objeto(X).

acima_de(X, Y) :- sobre(X, Y).
%%%acima(B, Mesa) :- sobre(B, Y).

/*
  acima_de(B, mesa).
          B = a;
          B = b.
*/