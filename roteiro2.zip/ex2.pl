prova(Formula) :- prova(Formula, Resposta), Resposta = verdade.

prova(verdade, verdade).
prova(falso, falso).

prova(verdade, nao(falso)).
prova(falso, nao(verdade)).

prova(nao(X), Resposta) :- prova(RespostaX, Resposta),
                           Resposta = falso, RespostaX = verdade; Resposta = verdade, RespostaX = falso.

prova(e(falso,falso), falso).
prova(e(verdade, verdade), verdade).
prova(e(falso,verdade), falso).
prova(e(verdade, falso), falso).
prova(e(X, Y), Resposta) :- prova(X, RespostaX), prova(Y, RespostaY),
                           RespostaX = verdade, RespostaY = verdade;
                           Resposta = falso.

prova(ou(verdade, verdade), verdade).
prova(ou(falso, verdade), verdade).
prova(ou(verdade, falso), verdade).
prova(ou(falso, falso), falso).
prova(ou(X, Y), Resposta) :- prova(X, RespostaX), prova(Y, RespostaY),
                             RespostaX = falso, RespostaY = falso;
                             Resposta = verdade.



prova(impl(verdade, verdade), verdade).
prova(impl(verdade, falso), falso).
prova(impl(falso, falso), verdade).
prova(impl(falso, verdade), verdade).
prova(impl(X, Y), Resposta) :- prova(X, RespostaX), prova(Y, RespostaY),
                               RespostaX = verdade, RespostaY = falso;
                               Resposta = verdade.

prova(equiv(falso, falso), verdade).
prova(equiv(verdade, verdade), verdade).
prova(equiv(verdade, falso), falso).
prova(equiv(falso, verdade), falso).
prova(equiv(X, Y), Resposta) :-  prova(X, RespostaX), prova(Y, RespostaY),
                                 RespostaX = verdade, RespostaY = verdade;
                                 RespostaX = falso, RespostaY = falso;
                                 Resposta = falso.