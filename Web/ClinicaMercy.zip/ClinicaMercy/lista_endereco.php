<?php
    require "conexaoMysql.php";
    $pdo = mysqlConnect();
        try {
 
        $sql = <<<SQL
        SELECT *
        FROM base_enderecos_ajax
SQL;
        
        $stmt = $pdo->query($sql);
       } catch (Exception $e) {
        exit('Ocorreu uma falha: ' . $e->getMessage());
       }
?>

<!doctype html>
<html lang="pt-BR">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Funcionários Cadastrados</title>
    <link rel="shortcut icon" href="./img/mercy2.png" type="image/x-icon">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-alpha3/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-CuOF+2SnTUfTwSZjCXf01h7uYhfOBuxIhGKPbfEJ3+FqH/s6cIFN9bGr1HmAg4fQ" crossorigin="anonymous">
    <style>
        body {
            background-image: url("img/bg1.jpg");
            background-size: cover;
        }

        html {
            margin: 0;
            font-family: Roboto, Oxygen, Ubuntu, Cantarell, 'Open Sans', 'Helvetica Neue', sans-serif;
            text-decoration: none;
            font-size: 1rem;
        }

        header {            
            text-align: center;
            width: 100%;
            color: white;
            top: 0;
            left: 0;
        }

        h3{
            font-family:cursive;
            color: #0ce8f0;
        }

        nav {
            text-align: center;
            padding: 35px;
            background-color: #0ce8f0;
            width: 100%;
            background-image: linear-gradient(315deg, #0ce8f0 58%, #000000 50%);
            overflow: hidden;
        }

        a {
            margin-left: 16%;
            color: white;
            text-decoration: none;
            padding: 25px;
            font-size: 1.5rem;
        }

        a:hover {
            color: #ffea2f;
        }

        #a1:hover {
            color: #ffea2f;
        }

        #a2:hover {
            color: #ffea2f;
        }

        footer {
            width: 100%;
            background-color: rgb(12, 232, 240);
            height: 70%;
            text-align: center;
        }

        main {
            margin: auto;
            padding-bottom: 28px;
            margin-bottom: 15.5%;
            margin-top: 50px;
        }

        #logo {
            float: left;
            margin: 0 15px;
            width: 80px;
            height: 80px;
            border-radius: 50%;
            border: 3px solid white;
        }

        @media (max-width: 768px) {
            a {
                margin-left: 0;
                font-size: 1.2rem;
                padding: 20px;
                color: white;
            }
        }
    </style>
</head>
    <body>
        <header>
            <nav>
                <img id="logo" src="./img/teste2.png" alt="Logo">
                <a href="./form_funcionario.html">Novo Funcionário </a>
                <a href="./form_paciente.html">Novo Paciente</a>
                <a href="./lista_funcionarios.php">Listar Funcionários </a>
                <a href="./lista_paciente.php">Listar Pacientes</a>
                <a href="./lista_endereco.php">Listar Endereços </a>
                <a href="./lista_agendamento.php">Listar Agendamentos</a>
            </nav>
        </header>

    <main>
        <div class="container">
            <h3>Listagem dos endereços auxiliares AJAX cadastrados;</h3>

            <table class="table table-striped table-hover">
                <tr>
                    <!-- cep logradouro bairro cidade estado -->
                    <th>Cep</th>
                    <th>Logradouro</th>
                    <th>Bairro</th>
                    <th>Cidade</th>
                    <th>estado</th>                             
                </tr>

                <?php
        while ($row = $stmt->fetch()) {
        
        $cep = htmlspecialchars($row["cep"]);
        $logradouro = htmlspecialchars($row["logradouro"]);
        $bairro = htmlspecialchars($row["bairro"]);
        $cidade = htmlspecialchars($row["cidade"]);
        $estado = htmlspecialchars($row["estado"]);
    
        
        echo <<<HTML
            <tr>
            <td>$cep</td> 
            <td>$logradouro</td>
            <td>$bairro</td>
            <td>$cidade</td>
            <td>$estado</td>        
            </tr> 
HTML;
        }
        ?>
            </table>
        </div>
    </main>

        <footer><em>Clínica Mercy </em> Copyright© 2020.</footer>

    </body>
</html>