<?php

    //Voltar para organizar AJAX

    require "conexaoMysql.php";
    $pdo = mysqlConnect();

    $nome = $email = $telefone = "";
    $data_agendamento = $horario = "";

    if(isset($_POST["nome"]))
        $nome = $_POST["nome"];

    if(isset($_POST["email"]))
        $email = $_POST["email"];

    if(isset($_POST["telefone"]))
        $telefone = $_POST["telefone"];

    if(isset($_POST["data_agendamento"]))
        $data_agendamento = $_POST["data_agendamento"];

    if(isset($_POST["horario"]))
        $horario = $_POST["horario"];

    if(isset($_POST["nome_medico"]))
        $nome_medico = $_POST["nome_medico"];

    $nome = htmlspecialchars($nome);
    $email = htmlspecialchars($email);
    $telefone = htmlspecialchars($telefone);
    $horario = htmlspecialchars($horario);

try {
    $sql = <<<SQL
    INSERT INTO agenda (nome, email, telefone, data_agendamento, horario)
    VALUES (?, ?, ?, ?, ?)
SQL;
  
    $stmt = $pdo->prepare($sql);
    $stmt->execute([
        $nome, $email, $telefone, $data_agendamento, $horario
    ]);
    
    header("location: form_agendamento.html");
    exit();
  
  } 
  catch (Exception $e) {  
    if ($e->errorInfo[1] === 1062)
      exit('Dados duplicados: ' . $e->getMessage());
    else
      exit('Falha ao cadastrar os dados: ' . $e->getMessage());
  }

?>