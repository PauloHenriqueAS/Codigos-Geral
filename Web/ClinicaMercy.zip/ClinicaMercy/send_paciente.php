<?php

    require "conexaoMysql.php";
    $pdo = mysqlConnect();

    $nome = $email = $telefone = $cep = $logradouro = $bairro = $cidade =  $estado = " ";
    $peso = $altura = $tipo_sanguineo = " ";
    $codigo = "";

    if(isset($_POST["nome"]))
        $nome = $_POST["nome"];

    if(isset($_POST["email"]))
        $email = $_POST["email"];
    
    if(isset($_POST["telefone"]))
        $telefone = $_POST["telefone"];

    if(isset($_POST["cep"]))
        $cep = $_POST["cep"];

    if(isset($_POST["logradouro"]))
        $logradouro = $_POST["logradouro"];

    if(isset($_POST["bairro"]))
        $bairro = $_POST["bairro"];
      
    if(isset($_POST["cidade"]))
        $cidade = $_POST["cidade"];    

    if(isset($_POST['estado']))
        $estado = $_POST['estado'];

        if(isset($_POST["peso"]))
        $peso = $_POST["peso"];
      
    if(isset($_POST["altura"]))
        $altura = $_POST["altura"];    

    if(isset($_POST['tipo_sanguineo']))
        $tipo_sanguineo = $_POST['tipo_sanguineo'];


    $nome = htmlspecialchars($nome);
    $email = htmlspecialchars($email);
    $telefone = htmlspecialchars($telefone);
    $cep = htmlspecialchars($cep);
    $logradouro = htmlspecialchars($logradouro);
    $bairro = htmlspecialchars($bairro);
    $cidade = htmlspecialchars($cidade);
    $estado = htmlspecialchars($estado);
    $peso =  htmlspecialchars($peso);
    $altura =htmlspecialchars($altura);
    
    $sql1 = <<<SQL
   INSERT INTO pessoa (nome, email, telefone, cep, logradouro, bairro, cidade, estado)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?)
SQL;

    $sql2 = <<<SQL
    INSERT INTO paciente (peso, altura, tipo_sanguineo, codigo)
        VALUES (?, ?, ?, ?)
SQL;


try {
    $pdo->beginTransaction();
      
    $stmt1 = $pdo->prepare($sql1);
    $stmt1->execute([
        $nome, $email, $telefone, $cep, $logradouro, $bairro, $cidade, $estado
    ]);

    $codigo = $pdo->lastInsertId();
    $stmt2 = $pdo->prepare($sql2);
    $stmt2->execute([
        $peso, $altura, $tipo_sanguineo, $codigo
        ]);
    
    $pdo->commit();
    header("location: form_paciente.html");
    exit();
  
  } 
  catch (Exception $e) {  
    if ($e->errorInfo[1] === 1062)
      exit('Dados duplicados: ' . $e->getMessage());
    else
      exit('Falha ao cadastrar os dados: ' . $e->getMessage());
  }
?>