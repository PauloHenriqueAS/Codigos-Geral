<?php

    require "conexaoMysql.php";
    $pdo = mysqlConnect();

    $nome = $email = $telefone = $cep = $logradouro = $bairro = $cidade =  $estado = " ";
    $peso = $altura = $tipo_sanguineo = " ";
    $codigo = "";
    $especialidade = $crm = "";
    $data_contrato = $salario = $senha_hash = "";

    if(isset($_POST["nome"]))
        $nome = $_POST["nome"];

    if(isset($_POST["email"]))
        $email = $_POST["email"];
    
    if(isset($_POST["telefone"]))
        $telefone = $_POST["telefone"];

    if(isset($_POST["cep"]))
        $cep = $_POST["cep"];

    if(isset($_POST["logradouro"]))
        $logradouro = $_POST["logradouro"];

    if(isset($_POST["bairro"]))
        $bairro = $_POST["bairro"];
      
    if(isset($_POST["cidade"]))
        $cidade = $_POST["cidade"];    

    if(isset($_POST['estado']))
        $estado = $_POST['estado'];

    if(isset($_POST["especialidade"]))
        $especialidade = $_POST["especialidade"];

    if(isset($_POST["crm"]))
        $crm = $_POST["crm"];

    if(isset($_POST["data_contrato"]))
        $data_contrato = $_POST["data_contrato"];

    if(isset($_POST["salario"]))
        $salario = $_POST["salario"];

    if(isset($_POST["senha_hash"]))
        $senha_hash = $_POST["senha_hash"];

    $nome = htmlspecialchars($nome);
    $email = htmlspecialchars($email);
    $telefone = htmlspecialchars($telefone);
    $cep = htmlspecialchars($cep);
    $logradouro = htmlspecialchars($logradouro);
    $bairro = htmlspecialchars($bairro);
    $cidade = htmlspecialchars($cidade);
    $estado = htmlspecialchars($estado);
    $peso =  htmlspecialchars($peso);
    $altura = htmlspecialchars($altura);
    
    $data_contrato = htmlspecialchars($data_contrato);
    $salario = htmlspecialchars($salario);
    $senha_hash = password_hash($senha, PASSWORD_DEFAULT);
    
    $especialidade = htmlspecialchars($especialidade);
    $crm = htmlspecialchars($crm);

    $sql1 = <<<SQL
        INSERT INTO pessoa (nome, email, telefone, cep, logradouro, bairro, cidade, estado)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?)
SQL;

    $sql2 = <<<SQL
        INSERT INTO funcionario (data_contrato, salario, senha_hash, codigo)
        VALUES (?, ?, ?, ?)
SQL;

if($crm != NULL){
    $sql3 = <<<SQL
        INSERT INTO medico (especialidade, crm, codigo)
        VALUES (?, ?, ?)
SQL;
}


try {
    $pdo->beginTransaction();
      
    $stmt1 = $pdo->prepare($sql1);
    $stmt1->execute([
        $nome, $email, $telefone, $cep, $logradouro, $bairro, $cidade, $estado
    ]);

    $codigo = $pdo->lastInsertId();
    $stmt2 = $pdo->prepare($sql2);
    $stmt2->execute([
        $data_contrato, $salario, $senha_hash, $codigo
    ]);

    if($crm != NULL){
        $stmt3 = $pdo->prepare($sql3);
        $stmt3->execute([
            $especialidade, $crm, $codigo
        ]);
    }

    $pdo->commit();
    header("location: form_funcionario.html");
    exit();
  
  } 
  catch (Exception $e) {  
    if ($e->errorInfo[1] === 1062)
      exit('Dados duplicados: ' . $e->getMessage());
    else
      exit('Falha ao cadastrar os dados: ' . $e->getMessage());
  }
?>