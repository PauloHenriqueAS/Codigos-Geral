package com.github.PauloHenriqueAS.citis_api;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CitisApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(CitisApiApplication.class, args);
	}

}
